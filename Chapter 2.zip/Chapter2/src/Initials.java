/* Program: initials.java         Date: 2/8/2022
 
Purpose: Output Initials

Author: Tyler Grewal 
School: CHHS
Course: Computer Science 20
*/

public class Initials
{

	public static void main(String[] args) 
	{
		System.out.println("*******    \t******\n   *     \t*\n   *     \t*   **\n   *     \t*    *\n   *   O\t******  O");
	}

}

/*Screen Dump
 
 
*******    	******
   *     	*
   *     	*   **
   *     	*    *
   *   O	******  O
  
  */